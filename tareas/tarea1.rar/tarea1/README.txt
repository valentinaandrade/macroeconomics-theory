Esta carpeta contiene todos los archivos para poder generar la tarea N°1 de Teoría Macroeconómica I
Estudiante: Valentina Andrade
Fecha de entrega: 17 de abril 2021

La carpeta contiene las siguientes subcarpetas que corresponden a cada uno de los 4 items de preguntas de la tarea.
Dentro de ellas encontrarán 2 clasea de archivos. Los .mlx que son una guía de como se ejecuta cada codigo
y los .m que son las funciones que fui ejecutando en los .mlx. A su vez, las respuestas son contestadas dentro del .mlx.


-problem1montecarlo
	- problemontecarlo.mlx
	- problemontecarlo.pdf
	- funciones: plotxx.m, algortimo1.m, algoritmo2.m, etc...

- detrending
	- detrending.mlx
	- detrending.pdf
	- funciones: hp_filter.m, hp_figure.m, figuredesceiptive.m, importdata.m

- roots
	- roots.mlx
	- roots.pdf
	- funciones: newtonraphson.m, bisection.m, ...

- irf
	- irf.mlx
	- irf.pdf
	- @web : carpeta que contiene api del banco mundial =) fue un desafio pero lo logre :D
	- funciones: hp_filter, etc. 

Por último, para facilitar su lectura cada carpeta tiene su pdf con la compilación del ejercicio.